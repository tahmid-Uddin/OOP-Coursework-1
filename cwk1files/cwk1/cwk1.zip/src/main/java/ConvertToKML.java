/**
 * Program to general a KML file from GPS track data stored in a file,
 * for the Advanced task of COMP1721 Coursework 1.
 *
 * @author Tahmid Fahim Uddin
 */
public class ConvertToKML {
  public static void main(String[] args) {
    // OPTIONAL: implenent the ConvertToKML application here
  }
}
